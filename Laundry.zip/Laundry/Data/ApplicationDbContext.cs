﻿using Laundry.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Laundry.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public DbSet<WashModel> washModels { get; set; }
        public DbSet<DryModel> dryModels { get; set; }
        public DbSet<ReportModel> reportModels { get; set; }
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        protected override void OnConfiguring(DbContextOptionsBuilder options)
    => options.UseSqlServer(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=aspnet-Laundry-3B0C744D-AB4F-4AE7-B83A-949AD72434DA;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        public ApplicationDbContext()
        {
        }
    }
}
