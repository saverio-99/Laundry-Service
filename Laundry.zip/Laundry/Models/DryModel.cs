﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Laundry.Models
{
    public class DryModel
    {
        public int Id { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 10)]
        [DisplayName("Student's full name")]
        public string FullName { get; set; }

        [Required]
        [Range(1, 400)]
        [DisplayName("Student's room")]
        public int Room { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [DisplayName("Appointment's date")]
        public DateTime DryDate { get; set; }

        [Required]
        [DataType(DataType.Time)]
        [DisplayName("Appointment's hour")]
        public TimeSpan Hour { get; set; }

        [Required]
        [Range(1, 3)]
        [DisplayName("Dryer (1-3)")]
        public int Dryer { get; set; }

        public DryModel(int id, string fullName, int room, DateTime dryDate, TimeSpan hour, int dryer)
        {
            Id = id;
            FullName = fullName;
            Room = room;
            DryDate = dryDate;
            Hour = hour;
            Dryer = dryer;
        }
        public DryModel()
        {

        }
    }
}
