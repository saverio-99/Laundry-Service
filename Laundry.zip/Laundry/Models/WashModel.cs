﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Laundry.Models
{
    public class WashModel
    {
        public int Id { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 10)]
        [DisplayName("Student's full name")]
        public string FullName { get; set; }

        [Required]
        [Range(1, 400)]
        [DisplayName("Student's room")]
        public int Room { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [DisplayName("Wash date")]
        public DateTime WashDate { get; set; }

        [Required]
        [DataType(DataType.Time)]
        [DisplayName("Wash hour")]
        public TimeSpan Hour { get; set; }

        [Required]
        [Range(1, 5)]
        [DisplayName("Washing machine (1-5)")]
        public int Machine { get; set; }

        public WashModel(int id, string fullName, int room, DateTime washDate, TimeSpan hour, int machine)
        {
            Id = id;
            FullName = fullName;
            Room = room;
            WashDate = washDate;
            Hour = hour;
            Machine = machine;
        }

        public WashModel()
        {
        }
    }
}
