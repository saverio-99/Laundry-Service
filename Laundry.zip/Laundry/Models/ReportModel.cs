﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Laundry.Models
{
    public class ReportModel
    {
        public int Id { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 10)]
        [DisplayName("Title")]
        public string Title { get; set; }

        [Required]
        [DisplayName("Description")]
        public string Description { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [DisplayName("Date")]
        public DateTime ReportDate { get; set; }

        [Required]
        [DisplayName("Tenant")]
        public string Tenant { get; set; }

        public ReportModel(int id, string title, string description, DateTime reportDate, string tenant)
        {
            Id = id;
            Title = title;
            Description = description;
            ReportDate = reportDate;
            Tenant = tenant;
        }

        public ReportModel()
        {

        }
    }
}
