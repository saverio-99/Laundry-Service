﻿using Laundry.Data;
using Laundry.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Laundry.Controllers
{
    [Authorize]
    public class ReportController : Controller
    {
        private ApplicationDbContext context;

        public ReportController()
        {
            context = new ApplicationDbContext();
        }
        protected override void Dispose(bool disposing)
        {
            context.Dispose();
        }

        // GET: Report
        [AllowAnonymous]
        public ActionResult Index()
        {
            //the next line of code enables us to display all records from the database
            List<ReportModel> reportModels = context.reportModels.ToList();

            return View("Index", reportModels);
        }
        public ActionResult Details(int id)
        {
            //the next line of code enables us to display One record from the database
            ReportModel reportModel = context.reportModels.SingleOrDefault(r => r.Id == id);

            return View("Details", reportModel);
        }

        public ActionResult Create()
        {//the next line of code enables us to display the Create form, so we can creat a new item in our db
            return View("ReportForm", new ReportModel());
        }

        public ActionResult Edit(int id)
        {
            ReportModel reportModel = context.reportModels.SingleOrDefault(r => r.Id == id);

            return View("ReportForm", reportModel);
        }

        public ActionResult ProcessCreate(ReportModel reportModel)
        {
            ReportModel report = context.reportModels.SingleOrDefault(r => r.Id == reportModel.Id);

            //edit & update the db
            if (report != null)
            {
                report.Title = reportModel.Title;
                report.Description = reportModel.Description;
                report.ReportDate = reportModel.ReportDate;
                report.Tenant = reportModel.Tenant;
                context.SaveChanges();
            }
            //create a new record
            else
            {
                context.reportModels.Add(reportModel);
                context.SaveChanges();
            }
            return View("Details", reportModel);
        }

        public ActionResult Delete(int id)
        {
            //the next lines of code enables us to Delete/Remove One record from the database
            //this line points out a single record from the db
            ReportModel reportModel = context.reportModels.SingleOrDefault(r => r.Id == id);
            //this line changes it's state to deleted - this means the record is going to be removed
            context.Entry(reportModel).State = EntityState.Deleted;
            //and this line updates the db after the item was deleted
            context.SaveChanges();

            return Redirect("/Report");
        }
    }
}
