﻿using Laundry.Data;
using Laundry.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Laundry.Controllers
{   
    [Authorize]
    public class DryController : Controller
    {
        private ApplicationDbContext context;

        public DryController()
        {
            context = new ApplicationDbContext();
        }
        protected override void Dispose(bool disposing)
        {
            context.Dispose();
        }

        // GET: Dry
        [AllowAnonymous]
        public ActionResult Index()
        {
            //the next line of code enables us to display all records from the database
            List<DryModel> dryModels = context.dryModels.ToList();

            return View("Index", dryModels);
        }
        public ActionResult Details(int id)
        {
            //the next line of code enables us to display One record from the database
            DryModel dryModel = context.dryModels.SingleOrDefault(d => d.Id == id);

            return View("Details", dryModel);
        }

        public ActionResult Create()
        {//the next line of code enables us to display the Create form, so we can creat a new item in our db
            return View("DryForm", new DryModel());
        }

        public ActionResult Edit(int id)
        {
            DryModel dryModel = context.dryModels.SingleOrDefault(d => d.Id == id);

            return View("DryForm", dryModel);
        }

        public ActionResult ProcessCreate(DryModel dryModel)
        {
            DryModel dry = context.dryModels.SingleOrDefault(d => d.Id == dryModel.Id);

            //edit & update the db
            if (dry != null)
            {
                dry.FullName = dryModel.FullName;
                dry.Room = dryModel.Room;
                dry.DryDate = dryModel.DryDate;
                dry.Hour = dryModel.Hour;
                dry.Dryer = dryModel.Dryer;

                context.SaveChanges();
            }
            //create a new record
            else
            {
                context.dryModels.Add(dryModel);
                context.SaveChanges();
            }
            return View("Details", dryModel);
        }

        public ActionResult Delete(int id)
        {
            //the next lines of code enables us to Delete/Remove One record from the database
            //this line points out a single record from the db
            DryModel dryModel = context.dryModels.SingleOrDefault(d => d.Id == id);
            //this line changes it's state to deleted - this means the record is going to be removed
            context.Entry(dryModel).State =EntityState.Deleted;
            //and this line updates the db after the item was deleted
            context.SaveChanges();

            return Redirect("/Dry");
        }
    }
}
