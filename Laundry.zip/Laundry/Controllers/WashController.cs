﻿using Laundry.Data;
using Laundry.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Laundry.Controllers
{
    [Authorize]
    
    public class WashController : Controller
    {
        private ApplicationDbContext context;

        public WashController()
        {
            context = new ApplicationDbContext();
        }
        protected override void Dispose(bool disposing)
        {
            context.Dispose();
        }

        // GET: Wash
        [AllowAnonymous]
        public ActionResult Index()
        {
            //the next line of code enables us to display all records from the database
            List<WashModel> washModels = context.washModels.ToList();

            return View("Index", washModels);
        }
        public ActionResult Details(int id)
        {
            //the next line of code enables us to display One record from the database
            WashModel washModel = context.washModels.SingleOrDefault(w => w.Id == id);

            return View("Details", washModel);
        }

        public ActionResult Create()
        {//the next line of code enables us to display the Create form, so we can creat a new item in our db
            return View("WashForm", new WashModel());
        }

        public ActionResult Edit(int id)
        {
            WashModel washModel = context.washModels.SingleOrDefault(w => w.Id == id);

            return View("WashForm", washModel);
        }

        public ActionResult ProcessCreate(WashModel washModel)
        {
            WashModel wash = context.washModels.SingleOrDefault(w => w.Id == washModel.Id);

            //edit & update the db
            if (wash != null)
            {
                wash.FullName = washModel.FullName;
                wash.Room = washModel.Room;
                wash.WashDate = washModel.WashDate;
                wash.Hour = washModel.Hour;
                wash.Machine = washModel.Machine;

                context.SaveChanges();
            }
            //create a new record
            else
            {
                context.washModels.Add(washModel);
                context.SaveChanges();
            }
            return View("Details", washModel);
        }

        public ActionResult Delete(int id)
        {
            //the next lines of code enables us to Delete/Remove One record from the database
            //this line points out a single record from the db
            WashModel washModel = context.washModels.SingleOrDefault(w => w.Id == id);
            //this line changes it's state to deleted - this means the record is going to be removed
            context.Entry(washModel).State =EntityState.Deleted;
            //and this line updates the db after the item was deleted
            context.SaveChanges();

            return Redirect("/Wash");
        }
    }
}
